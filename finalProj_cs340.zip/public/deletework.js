function deleteWork(id){
    $.ajax({
        url: '/work/' + id,
        type: 'DELETE',
        success: function(result){
            window.location.reload(true);
        }
    })
};
