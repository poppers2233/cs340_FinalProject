function updateWork(id){
    $.ajax({
        url: '/work/' + id,
        type: 'PUT',
        data: $('#update-work').serialize(),
        success: function(result){
            window.location.replace("./");
        }
    })
};
