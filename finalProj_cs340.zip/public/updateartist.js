function updateArtist(id){
    $.ajax({
        url: '/artist/' + id,
        type: 'PUT',
        data: $('#update-artist').serialize(),
        success: function(result){
            window.location.replace("./");
        }
    })
};
