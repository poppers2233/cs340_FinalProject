function selectGroup(id){
    $("#group-selector").val(id);
}
