function deleteType(id){
    $.ajax({
        url: '/type/' + id,
        type: 'DELETE',
        success: function(result){
            window.location.reload(true);
        }
    })
};
