function updateGroup(id){
    $.ajax({
        url: '/group/' + id,
        type: 'PUT',
        data: $('#update-group').serialize(),
        success: function(result){
            window.location.replace("./");
        }
    })
};
