function deleteGroup(id){
    $.ajax({
        url: '/group/' + id,
        type: 'DELETE',
        success: function(result){
            window.location.reload(true);
        }
    })
};
