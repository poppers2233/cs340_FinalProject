function selectType(id){
    $("#type-selector").val(id);
}
