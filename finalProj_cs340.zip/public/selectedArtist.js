function selectArtist(id){
    $("#artist-selector").val(id);
}
