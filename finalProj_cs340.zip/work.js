module.exports = function(){
    var express = require('express');
    var router = express.Router();

    function getGroups(res, mysql, context, complete){
        mysql.pool.query("SELECT id, name FROM Group_", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.groups  = results;
            complete();
        });
    }
	

    function getArtists(res, mysql, context, complete){
        mysql.pool.query("SELECT id, first_name, last_name, gid, dob FROM Artist", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.artists = results;
            complete();
        });
    }
	
	function getTypes(res, mysql, context, complete){
        mysql.pool.query("SELECT id, name FROM Type_", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.types = results;
            complete();
        });
    }
	
	function getWorks(res, mysql, context, complete){
        mysql.pool.query("SELECT id, gid, aid, name, type_id, doc FROM Work_", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.works = results;
            complete();
        });
    }


    function getWork(res, mysql, context, id, complete){
        var sql = "SELECT id, gid, aid, name, type_id, doc FROM Work_ WHERE id = ?";
        var inserts = [id];
	console.log(inserts);
        mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.work = results[0];
            complete();
        });
    }

    /*Display all people. Requires web based javascript to delete users with AJAX*/

    router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["deletework.js"];
        var mysql = req.app.get('mysql');
        getGroups(res, mysql, context, complete);
		getTypes(res, mysql, context, complete);
        getArtists(res, mysql, context, complete);
		getWorks(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 4){
                res.render('works', context);
            }

        }
    });

    /* Display one person for the specific purpose of updating people */

    router.get('/:id', function(req, res){
        callbackCount = 0;
        var context = {};
        context.jsscripts = ["selectedGroup.js", "updatework.js","selectedArtist.js","selectedType.js"];
        var mysql = req.app.get('mysql');
	console.log(req.params.id);
        getArtists(res, mysql, context, complete);
        getGroups(res, mysql, context, complete);
		getTypes(res, mysql, context, complete);
		getWork(res, mysql, context, req.params.id, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 4){
                res.render('update-work', context);
		console.log(context);
            }

        }
    });

    /* Adds a person, redirects to the people page after adding */

    router.post('/', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "INSERT INTO Work_ (gid, aid, name, type_id, doc) VALUES (?,?,?,?,?)";
        var inserts = [req.body.gid, req.body.aid, req.body.name, req.body.type_id, req.body.doc];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.redirect('/work');
            }
        });
    });

    /* The URI that update data is sent to in order to update a person */

    router.put('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "UPDATE Work_ SET gid=?, aid=?, name=?, type_id=?, doc=? WHERE id=?";
        var inserts = [req.body.gid, req.body.aid,req.body.name, req.body.type_id, req.body.doc, req.params.id];
	console.log(inserts);
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.status(200);
                res.end();
            }
        });
    });

    /* Route to delete a person, simply returns a 202 upon success. Ajax will handle this. */

    router.delete('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "DELETE FROM Work_ WHERE id = ?";
        var inserts = [req.params.id];
        sql = mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.status(400);
                res.end();
            }else{
                res.status(202).end();
            }
        })
    })

    return router;
}();
