var mysql = require('mysql');
var pool = mysql.createPool({
  connectionLimit : 10,
  host            : 'classmysql.engr.oregonstate.edu',
  user            : 'cs340_mugicaj',
  password        : '9894',
  database        : 'cs340_mugicaj'
});
module.exports.pool = pool;
