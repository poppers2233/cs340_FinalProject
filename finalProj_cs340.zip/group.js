module.exports = function(){
    var express = require('express');
    var router = express.Router();


    function getGroups(res, mysql, context, complete){
        mysql.pool.query("SELECT id, name, gMem1, gMem2, gMem3, gMem4, gMem5, doc FROM Group_", function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.groups = results;
            complete();
        });
    }

    function getGroup(res, mysql, context, id, complete){
        var sql = "SELECT id, name, gMem1, gMem2, gMem3, gMem4, gMem5, doc FROM Group_ WHERE id = ?";
        var inserts = [id];
	console.log(inserts);
        mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }
            context.group = results[0];
            complete();
        });
    }

    /*Display all people. Requires web based javascript to delete users with AJAX*/

    router.get('/', function(req, res){
        var callbackCount = 0;
        var context = {};
        context.jsscripts = ["deletegroup.js"];
        var mysql = req.app.get('mysql');
        getGroups(res, mysql, context, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('groups', context);
            }

        }
    });

    /* Display one person for the specific purpose of updating people */

    router.get('/:id', function(req, res){
        callbackCount = 0;
        var context = {};
        context.jsscripts = ["updategroup.js"];
        var mysql = req.app.get('mysql');
	    console.log(req.params.id);
        getGroup(res, mysql, context, req.params.id, complete);
        function complete(){
            callbackCount++;
            if(callbackCount >= 1){
                res.render('update-group', context);
		console.log(context);
            }

        }
    });

    /* Adds a person, redirects to the people page after adding */

    router.post('/', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "INSERT INTO Group_ (name, gMem1, gMem2, gMem3, gMem4, gMem5, doc) VALUES (?,?,?,?,?,?,?)";
        var inserts = [req.body.name, req.body.gMem1, req.body.gMem2, req.body.gMem3, req.body.gMem4, req.body.gMem5, req.body.doc ];
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.redirect('/group');
            }
        });
    });

    /* The URI that update data is sent to in order to update a person */

    router.put('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "UPDATE Group_ SET name=?, gMem1=?, gMem2=?, gMem3=?, gMem4=?, gMem5=?, doc=? WHERE id=?";
        var inserts = [req.body.name, req.body.gMem1, req.body.gMem2, req.body.gMem3, req.body.gMem4, req.body.gMem5, req.body.doc, req.params.id];
	console.log(inserts);
        sql = mysql.pool.query(sql,inserts,function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.end();
            }else{
                res.status(200);
                res.end();
            }
        });
    });

    /* Route to delete a person, simply returns a 202 upon success. Ajax will handle this. */

    router.delete('/:id', function(req, res){
        var mysql = req.app.get('mysql');
        var sql = "DELETE FROM Group_ WHERE id = ?";
        var inserts = [req.params.id];
        sql = mysql.pool.query(sql, inserts, function(error, results, fields){
            if(error){
                res.write(JSON.stringify(error));
                res.status(400);
                res.end();
            }else{
                res.status(202).end();
            }
        })
    })

    return router;
}();
